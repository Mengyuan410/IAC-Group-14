#!/bin/bash

set +e


# Use a wild-card to specifiy that every file with this pattern represents a testcase file
TESTCASES="rt1/*_tb.v"
echo ${TESTCASES}
for i in ${TESTCASES};do
    TESTNAME=$(basename ${i} _tb.v)
    iverilog -Wall -g 2012 -s ${TESTNAME}_tb -o ${TESTNAME}_tb \ rt1/${TESTNAME}.v rt1/${TESTNAME}_tb.v 2> /dev/null

    RESULT=$?

    if [[ "${RESULT}" -ne 0 ]] ; then
    echo " Compiling of ${i}, Fail"
    exit
    else
    echo " Compiling of ${i}, Pass"
    fi

    ./${TESTNAME}_tb 2> /dev/null
    #suppress error output

    RESULT=$?
    if [[ "${RESULT}" -ne 0 ]] ; then
    echo " Execution of rt1/${i}, Fail"
    exit
    else
    echo " Execution of rt1/${i}, Pass"
    fi

done   