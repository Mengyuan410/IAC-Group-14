#!/bin/bash
set -eou pipefail

VF="rtl/*.v"
#extract all the program .v and put them into VF
for i in ${VF}; do
Name=$(basename ${i} .v)
iverilog -Wall -g  2012 -s ${Name}_tb -o ${Name}_tb \
 ${Name}_tb.v ${i}
#do the simulation

set +e
RESULT=$?
set -e
#put the result into RESULT
if [[ "${RESULT}" -ne 0 ]] ; then 
    echo "${i}, Fail"
else
    echo "${i}, Pass"
fi
#display the intepreted output.
done




