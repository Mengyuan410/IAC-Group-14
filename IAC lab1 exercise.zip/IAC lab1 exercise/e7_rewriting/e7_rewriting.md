e7 - Rewriting
--------------

Modify the module `multiplier` so that it contains no `if` or `else`
statements, but still has the same functionality. You can use any
other Verilog language constructs (i.e. keywords, operators, statements,
expressions) you like, as long as you don't use `if` or `else`.
